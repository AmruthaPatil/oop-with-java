package in.ac.kletech.library;

public class LibraryDemo {

	public static void main(String[] args) {
		
	      Library Amru=new Library(5,18,5,"cs");
	      Library Ria=new Library(3, 4, 2,"ec");
	      
          Amru.Reference();
          Amru.Lendingbook();
          Amru.Digital();
          Amru.Questionpaper();
          
          Ria.Reference();
          Ria.Lendingbook();
          Ria.Digital();
          Ria.Questionpaper();
		
	}

}
