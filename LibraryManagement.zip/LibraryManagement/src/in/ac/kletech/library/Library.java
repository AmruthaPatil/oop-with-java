package in.ac.kletech.library;

public class Library {
	private int referencetime;
	private int lendingtime;
	private int digitaltime;
	private String branch;
	
	static{
		System.out.println("				WELCOME TO LIBRARY");
		System.out.println("	student can sit for a maximum of 4hrs in reference section");
		System.out.println("	books available for lending but do not exced 15 days else charges applied");
		System.out.println("	model question paper available for cs, ec and civil dept.");
		System.out.println();
	}
	
	Library(int referencetime,int lendingtime,int digitaltime,String branch){
     	 this.referencetime=referencetime;
     	 this.lendingtime=lendingtime;
     	 this.digitaltime=digitaltime;
     	 this.branch=branch;
      }
	  
    public int getReferencetime() {
		return referencetime;
	}
    public int getLendingtime() {
		return lendingtime;
	}
    public int getDigitaltime() {
		return digitaltime;
	}
    public String getBranch() {
		return branch;
	}

	void Reference(){
		System.out.println("REFERENCE SECTION:");
     	 if(referencetime>4)
     		 System.out.println("sitting more than 4hrs is not allowed");
     	 else
     		 System.out.println("U can continue");
     	 System.out.println();
      }
      
	void Lendingbook(){
		System.out.println("LENDING SECTION:");
     	 if(lendingtime<15)
     		 System.out.println("No penalty");
     	 else if(lendingtime>15 && lendingtime<=22)
     		 System.out.println("Penalty: rs " + (lendingtime-15)*20);
     	 else if(lendingtime>22 && lendingtime<=29)
     		 System.out.println("Penalty: rs " + ((lendingtime-21)*50+(7*20)));
     	 else if(lendingtime>29 && lendingtime<=37)
     		System.out.println("Penalty: rs "+ ((lendingtime-29)*30+(lendingtime-21)*50+(7*20)));
     	 else if(lendingtime>38)
     		 System.out.println("Penalty: rs " +((lendingtime-38)*300+(lendingtime-29)*30+(lendingtime-21)*50+140));
     	 System.out.println();
      }
	
	void Digital(){
		System.out.println("DIGITAL SECTION:");
     	 if(digitaltime>4 && digitaltime<6)
     		 System.out.println("Digital section is open");
     	 else
     		 System.out.println("Digital section is closed");
     	 System.out.println();
      }
	
	void Questionpaper(){
		System.out.println("QUESTION PAPER SECTION:");
    	  if(branch=="cs")
    		  System.out.println("Computer science: year-2015, year-2014, year-2013 available");
    	  else if(branch=="ec")
    		  System.out.println("Electronic Communication: year-2015, year-2014, year-2013 available");
    	  else if(branch=="civil")
    		  System.out.println("civil: year-2015, year-2014, year-2013, year-2012 available");
    	  else
    		  System.out.println("question paper not available");
    	  System.out.println();
      }

}
