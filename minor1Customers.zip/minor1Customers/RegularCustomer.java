package in.ac.kletech.minor1Customers;

public class RegularCustomer extends Customer {
	
	private final double discount=0.02;
	private double finalBill;
	
	public RegularCustomer( int customerID,String customerName,long phoneNum,double billAmount) {
		super(customerID,customerName,phoneNum,billAmount);
	}
	
	double computeBill(){
		finalBill=getBillAmount()-getBillAmount()*discount;
		return finalBill;
	}
	
	void printCustomerInfo(){
		System.out.println("REGULAR CUSTOMER");
		System.out.println("customer id: "+getCustomerID());
		System.out.println("customer name: "+getCustomerName());
		System.out.println("customer contact number: "+getPhoneNum());
		System.out.println("customer bill amount : rs "+computeBill());
		System.out.println();
	}

}
