package in.ac.kletech.minor1Customers;

public class PrivilegedCustomer extends Customer{
	
	private String memberCardType;
	
	public PrivilegedCustomer( int customerID,String customerName,long phoneNum,double billAmount,String memberCardType) {
		super(customerID,customerName,phoneNum,billAmount);
		this.memberCardType=memberCardType;
	}
	
	double computeBill(){
		double temp=0;
		double finalBill;
		if(memberCardType=="platinum")
			temp=0.08;
		else if(memberCardType=="golden")
			temp=0.06;
		else if(memberCardType=="silver")
			temp=0.04;
		else System.out.println("invalid card type");
		finalBill=getBillAmount()-getBillAmount()*temp;
		return finalBill;
		
	}

	void printCustomerInfo(){
		System.out.println("PRIVILEGED CUSTOMER");
		System.out.println("customer id: "+getCustomerID());
		System.out.println("customer name: "+getCustomerName());
		System.out.println("customer contact number: "+getPhoneNum());
		System.out.println("customer card typr: " +memberCardType);
		System.out.println("customer bill amount : rs "+computeBill());
		System.out.println();
	}
}
