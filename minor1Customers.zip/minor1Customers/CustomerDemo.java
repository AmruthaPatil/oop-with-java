package in.ac.kletech.minor1Customers;

public class CustomerDemo {

	public static void main(String[] args) {
		 int c3=0;
		 int c1=0;
		 int c2=0;
	
	RegularCustomer[] r=new RegularCustomer[5];
	PrivilegedCustomer[] p=new PrivilegedCustomer[3];
	
	r[0]= new RegularCustomer(1, "ram", 1234567890, 100);
	r[1]= new RegularCustomer(2, "shyam", 1876543210, 200);
	r[2]= new RegularCustomer(3, "shiva", 1210987654, 300);
	r[3]= new RegularCustomer(3, "shiva", 1210987654, 100);
	r[4]= new RegularCustomer(3, "shiva", 1210987654, 500);
	
	p[0]=new PrivilegedCustomer(101, "sita", 1230984567, 1000, "golden");
	p[1]=new PrivilegedCustomer(103, "gita", 1357924680, 2000, "platinum");
	p[2]=new PrivilegedCustomer(109, "shreya", 1357000680, 5000, "silver");
	
	
	for(int i=0;i<5;i++){
		r[i].printCustomerInfo();
	if(r[i].getCustomerID()==1)
		c1++;
	if(r[i].getCustomerID()==2)
		c2++;
	if(r[i].getCustomerID()==3)
		c3++;
	if(c1>=2 || c2>=2 || c3>=2)
	{
		double temp;
		temp=r[i].getBillAmount()-r[i].getBillAmount()*0.05;
		System.out.println("thanks for revisiting");
		System.out.println("new bill amount is: rs "+temp);
		System.out.println();
	}
	}
	
	for(int i=0;i<3;i++)
	p[i].printCustomerInfo();
	
	}

}
