package in.ac.kletech.minor1Customers;

abstract public class Customer {
	
	private int customerID;
	private String customerName;
	private long phoneNum;
	private double billAmount;
	
	public Customer( int customerID,String customerName,long phoneNum,double billAmount) {
		this.customerID=customerID;
		this.customerName=customerName;
		this.phoneNum=phoneNum;
		this.billAmount=billAmount;
	}
	
	public int getCustomerID() {
		return customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public long getPhoneNum() {
		return phoneNum;
	}
	public double getBillAmount() {
		return billAmount;
	}
	
	double computeBill(){
		return billAmount;
	}
	
	abstract void printCustomerInfo();
	
	

}
