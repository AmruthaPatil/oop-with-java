package ac.in.kletech.pokemon;

public class PokemonCalculate {

}
