package ac.in.kletech.pokemon;

public class PokemonDemo {

	public static void main(String[] args) {
		Pokemon1 piku=new Pokemon1(123, "pika", "electric", 50, 50,9,3);
		piku.display();
		piku.calPokeCP();
	
	}

}
