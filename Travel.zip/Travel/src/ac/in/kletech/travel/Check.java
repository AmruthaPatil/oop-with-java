package ac.in.kletech.travel;

public class Check {
	boolean checkBaggage(Traveller amru){
		if(amru.getBaggage()>0 && amru.getBaggage()<=40)
			return true;
		else
			return false;
		}
	
	boolean checkExpiry(Traveller amru){
		if(amru.getExpiry()>2001 && amru.getExpiry()<2025)
			return true;
		else 
			return false;
		}
	
	boolean checkNoc(Traveller amru){
		if(amru.isNOC()==true)
			return true;
		else 
			return false;
	}

}
