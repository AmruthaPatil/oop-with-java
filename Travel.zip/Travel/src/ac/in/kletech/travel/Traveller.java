package ac.in.kletech.travel;

public class Traveller {
	
	private int baggage;
	private int expiry;
	private boolean NOC;
	
	Traveller(int baggage,int expiry,boolean NOC)
	{
		this.baggage=baggage;
		this.expiry=expiry;
		this.NOC=NOC;
	}
	
	public int getBaggage() {
		return baggage;
	}
	public int getExpiry() {
		return expiry;
	}
	public boolean isNOC() {
		return NOC;
	}
	
}
