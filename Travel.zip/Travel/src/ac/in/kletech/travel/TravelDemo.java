package ac.in.kletech.travel;

public class TravelDemo {
	
public static void main(String[] args) {

	Check checkpoint =new Check();
		Traveller amru= new Traveller(30,2006,true);
		System.out.println(amru.getBaggage());
		System.out.println(amru.getExpiry());
		System.out.println(amru.isNOC());
		
	if(checkpoint.checkBaggage(amru)==true && checkpoint.checkExpiry(amru)==true && checkpoint.checkNoc(amru)==true)
		System.out.println("fly");
	else
		System.out.println("stay");
	
	}
}
